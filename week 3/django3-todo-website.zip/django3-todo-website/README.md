# django3-todo-website
todo website creating with django3 based on python3


# Demo
https://todobikash.pythonanywhere.com/
